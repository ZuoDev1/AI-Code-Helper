package com.example.aicodehelper.ai.rag;

import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.document.loader.ClassPathDocumentLoader;
import dev.langchain4j.data.document.splitter.DocumentByParagraphSplitter;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.rag.content.retriever.ContentRetriever;
import dev.langchain4j.rag.content.retriever.EmbeddingStoreContentRetriever;
import dev.langchain4j.store.embedding.EmbeddingStore;
import dev.langchain4j.store.embedding.EmbeddingStoreIngestor;
import dev.langchain4j.store.embedding.inmemory.InMemoryEmbeddingStore;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
@Configuration
@Slf4j
public class RagConfig {

    private static final String STORE_PATH = "/app/embeddings.bin";

    private final InMemoryEmbeddingStore<TextSegment> store;
    private final EmbeddingModel embeddingModel;

    @Getter
    private final Map<String, String> documentTextByFileName = new LinkedHashMap<>();

    public RagConfig(EmbeddingModel embeddingModel) {
        this.embeddingModel = embeddingModel;
        InMemoryEmbeddingStore<TextSegment> tempStore;
        try {
            tempStore = InMemoryEmbeddingStore.fromFile(Paths.get(STORE_PATH));
            log.info("✅ 向量库从文件加载成功");
        } catch (Exception e) {
            tempStore = new InMemoryEmbeddingStore<>();
            log.info("🆕 新建向量库");
        }
        this.store = tempStore;
    }

    @PreDestroy
    public void saveStore() {
        try {
            store.serializeToFile(Paths.get(STORE_PATH));
            log.info("✅ 向量库已保存");
        } catch (Exception e) {
            log.error("❌ 向量库保存失败", e);
        }
    }

    @Bean
    public EmbeddingStore<TextSegment> embeddingStore() {
        return store;
    }

    @Bean
    public ContentRetriever contentRetriever() {
        return EmbeddingStoreContentRetriever.builder()
                .embeddingStore(store)
                .embeddingModel(embeddingModel)
                .maxResults(5)
                .minScore(0.85)
                .build();
    }

    @PostConstruct
    public void ingestDocuments() {
        loadDocumentTextIndex();

        if (Files.exists(Paths.get(STORE_PATH))) {
            log.info("✅ 检测到向量文件，跳过导入");
            return;
        }

        log.info("⚠️ 首次启动，开始导入文档...");
        try {
            List<Document> documents = ClassPathDocumentLoader.loadDocuments("docs");
            log.info("加载了 {} 个文档", documents.size());

            DocumentByParagraphSplitter splitter = new DocumentByParagraphSplitter(1000, 200);

            EmbeddingStoreIngestor ingestor = EmbeddingStoreIngestor.builder()
                    .documentSplitter(splitter)
                    .embeddingModel(embeddingModel)
                    .embeddingStore(store)
                    .build();

            ingestor.ingest(documents);
            log.info("✅ 文档导入成功！使用硅基流动生成向量");
        } catch (Exception e) {
            log.error("❌ 文档导入失败，但不影响使用", e);
        }
    }

    public List<String> findLikelySourceFiles(String query, int limit) {
        if (query == null || query.isBlank() || documentTextByFileName.isEmpty()) {
            return List.of();
        }

        String[] keywords = query.toLowerCase()
                .replaceAll("[^\\p{IsAlphabetic}\\p{IsDigit}\\p{IsIdeographic}]+", " ")
                .trim()
                .split("\\s+");

        List<Map.Entry<String, Integer>> scored = new ArrayList<>();
        for (Map.Entry<String, String> entry : documentTextByFileName.entrySet()) {
            int score = 0;
            String text = entry.getValue().toLowerCase();
            for (String keyword : keywords) {
                if (keyword.length() < 2) {
                    continue;
                }
                if (text.contains(keyword)) {
                    score++;
                }
            }
            if (score > 0) {
                scored.add(Map.entry(entry.getKey(), score));
            }
        }

        scored.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        List<String> result = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : scored) {
            result.add(entry.getKey());
            if (result.size() >= limit) {
                break;
            }
        }
        return result;
    }

    private void loadDocumentTextIndex() {
        documentTextByFileName.clear();
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        try {
            Resource[] resources = resolver.getResources("classpath*:docs/*");
            for (Resource resource : resources) {
                String filename = resource.getFilename();
                if (filename == null) {
                    continue;
                }
                byte[] bytes = resource.getInputStream().readAllBytes();
                String text = new String(bytes, StandardCharsets.UTF_8);
                documentTextByFileName.put(filename, text);
            }
            log.info("已建立文档来源索引，共 {} 个文件", documentTextByFileName.size());
        } catch (IOException e) {
            log.error("建立文档来源索引失败", e);
        }
    }
}
