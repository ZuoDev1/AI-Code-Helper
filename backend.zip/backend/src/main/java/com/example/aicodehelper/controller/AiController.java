package com.example.aicodehelper.controller;

import com.example.aicodehelper.ai.AiCodeHelperService;
import com.example.aicodehelper.ai.rag.RagConfig;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/ai")
public class AiController {

    private static final String END_MARKER = "[DONE]";

    @Resource
    private AiCodeHelperService aiCodeHelperService;

    @Resource
    private RagConfig ragConfig;

    @GetMapping(value = "/chat", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<ServerSentEvent<String>> chat(
            @RequestParam int memoryId,
            @RequestParam String message) {

        try {
            String trimmedMessage = message == null ? "" : message.trim();
            log.info("Received chat request: memoryId={}, message={}", memoryId, trimmedMessage);

            if (isSimpleGreeting(trimmedMessage)) {
                return Flux.just(
                        dataEvent("""
                                你好！我是 AI 编程小助手，可以帮你：
                                - 解答编程学习问题
                                - 提供面试题思路
                                - 分析代码和报错
                                你可以直接描述问题，或贴出报错信息。
                                """),
                        endEvent()
                );
            }

            List<String> sourceFiles = ragConfig.findLikelySourceFiles(trimmedMessage, 3);
            if (!sourceFiles.isEmpty()) {
                log.info("Likely RAG source files for current query: {}", sourceFiles);
            } else {
                log.info("No likely RAG source files found for current query");
            }

            Flux<ServerSentEvent<String>> answerStream = aiCodeHelperService.chatStream(memoryId, trimmedMessage)
                    .filter(this::isDisplayableChunk)
                    .map(this::dataEvent);

            Flux<ServerSentEvent<String>> sourceStream = sourceFiles.isEmpty()
                    ? Flux.empty()
                    : Flux.just(dataEvent(buildSourceFooter(sourceFiles)));

            return answerStream
                    .concatWith(sourceStream)
                    .concatWith(Flux.just(endEvent()));
        } catch (Exception e) {
            log.error("Failed to process chat request", e);
            return Flux.just(
                    dataEvent("抱歉，处理请求时出现错误，请稍后重试。"),
                    endEvent()
            );
        }
    }

    private boolean isSimpleGreeting(String message) {
        if (message == null || message.isEmpty()) {
            return false;
        }
        String lower = message.toLowerCase().trim();
        return lower.matches("^(你好|您好|hi|hello|hey|早上好|晚上好|下午好|在吗|在嘛)$");
    }

    private boolean isDisplayableChunk(String chunk) {
        if (chunk == null) {
            return false;
        }

        String trimmed = chunk.trim();
        if (trimmed.isEmpty()) {
            return false;
        }

        String lower = trimmed.toLowerCase();
        return !lower.contains("<tool")
                && !lower.contains("</tool")
                && !lower.contains("\"tooltype\"")
                && !lower.contains("\"function\"")
                && !lower.contains("\"arguments\"")
                && !lower.contains("\"version\"");
    }

    private String buildSourceFooter(List<String> sourceFiles) {
        StringBuilder builder = new StringBuilder();
        builder.append("\n\n---\n");
        builder.append("**可能参考的本地文档来源：**\n");
        for (String sourceFile : sourceFiles) {
            builder.append("- ").append(sourceFile).append("\n");
        }
        return builder.toString();
    }

    private ServerSentEvent<String> dataEvent(String data) {
        return ServerSentEvent.<String>builder()
                .data(data)
                .build();
    }

    private ServerSentEvent<String> endEvent() {
        return ServerSentEvent.<String>builder()
                .event("end")
                .data(END_MARKER)
                .build();
    }
}
